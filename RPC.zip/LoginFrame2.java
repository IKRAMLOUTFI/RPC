import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.net.*;

public class LoginFrame2 extends JFrame {
    private JTextField usernameField;
    private JPasswordField passwordField;
    private JButton loginButton;
    private JButton registerButton;
    private JCheckBox showPasswordCheckBox;
    private Socket socket;
    private ObjectInputStream in;
    private ObjectOutputStream out;

    public LoginFrame2() {
        setTitle("Gestionnaire de Mots de Passe - Connexion");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        // Titre
        JLabel titleLabel = new JLabel("Gestionnaire de Mots de Passe");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 18));
        titleLabel.setHorizontalAlignment(SwingConstants.CENTER);
        gbc.gridx = 0; gbc.gridy = 0; gbc.gridwidth = 2;
        add(titleLabel, gbc);

        // Panel pour les champs de saisie
        JPanel inputPanel = new JPanel(new GridBagLayout());
        inputPanel.setBorder(BorderFactory.createTitledBorder("Informations de connexion"));

        // Champs de saisie
        usernameField = new JTextField(20);
        passwordField = new JPasswordField(20);
        showPasswordCheckBox = new JCheckBox("Afficher le mot de passe");

        gbc.gridwidth = 1;
        gbc.gridx = 0; gbc.gridy = 1;
        inputPanel.add(new JLabel("Nom d'utilisateur:"), gbc);
        gbc.gridx = 1;
        inputPanel.add(usernameField, gbc);

        gbc.gridx = 0; gbc.gridy = 2;
        inputPanel.add(new JLabel("Mot de passe:"), gbc);
        gbc.gridx = 1;
        inputPanel.add(passwordField, gbc);

        gbc.gridx = 1; gbc.gridy = 3;
        inputPanel.add(showPasswordCheckBox, gbc);

        gbc.gridx = 0; gbc.gridy = 1; gbc.gridwidth = 2;
        add(inputPanel, gbc);

        // Panel pour les boutons
        JPanel buttonPanel = new JPanel(new GridLayout(1, 2, 10, 0));
        loginButton = new JButton("Se connecter");
        registerButton = new JButton("Créer un compte");
        
        // Style des boutons
        loginButton.setBackground(new Color(70, 130, 180));
        loginButton.setForeground(Color.WHITE);
        registerButton.setBackground(new Color(34, 139, 34));
        registerButton.setForeground(Color.WHITE);

        buttonPanel.add(loginButton);
        buttonPanel.add(registerButton);

        gbc.gridx = 0; gbc.gridy = 2; gbc.gridwidth = 2;
        add(buttonPanel, gbc);

        // Actions des boutons
        loginButton.addActionListener(e -> {
            String username = usernameField.getText();
            String password = new String(passwordField.getPassword());
            authenticate(username, password, "LOGIN");
        });

        registerButton.addActionListener(e -> {
            String username = usernameField.getText();
            String password = new String(passwordField.getPassword());
            authenticate(username, password, "REGISTER");
        });

        // Afficher/masquer le mot de passe
        showPasswordCheckBox.addActionListener(e -> {
            if (showPasswordCheckBox.isSelected()) {
                passwordField.setEchoChar((char) 0);
            } else {
                passwordField.setEchoChar('•');
            }
        });

        // Instructions
        JLabel instructionLabel = new JLabel(
            "<html><center>Nouvel utilisateur ? Cliquez sur 'Créer un compte'<br>Déjà un compte ? Cliquez sur 'Se connecter'</center></html>");
        instructionLabel.setFont(new Font("Arial", Font.ITALIC, 11));
        instructionLabel.setHorizontalAlignment(SwingConstants.CENTER);
        gbc.gridx = 0; gbc.gridy = 3; gbc.gridwidth = 2;
        add(instructionLabel, gbc);

        // Centrer la fenêtre
        setLocationRelativeTo(null);
        setVisible(true);
    }

    private void authenticate(String username, String password, String action) {
        // Validation des champs
        if (username.trim().isEmpty() || password.trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Veuillez remplir tous les champs.", "Erreur", JOptionPane.ERROR_MESSAGE);
            return;
        }

        if (username.length() < 3) {
            JOptionPane.showMessageDialog(this, "Le nom d'utilisateur doit contenir au moins 3 caractères.", "Erreur", JOptionPane.ERROR_MESSAGE);
            return;
        }

        if (password.length() < 4) {
            JOptionPane.showMessageDialog(this, "Le mot de passe doit contenir au moins 4 caractères.", "Erreur", JOptionPane.ERROR_MESSAGE);
            return;
        }

        try {
            // Connexion au serveur
            socket = new Socket("localhost", 12345);
            
            // Créer les flux
            out = new ObjectOutputStream(socket.getOutputStream());
            out.flush();
            in = new ObjectInputStream(socket.getInputStream());

            // Envoyer la requête
            String request = action + ":" + username + ":" + password;
            out.writeObject(request);
            out.flush();

            // Lire la réponse
            String response = (String) in.readObject();

            if (response.startsWith("SUCCESS")) {
                if (action.equals("REGISTER")) {
                    JOptionPane.showMessageDialog(this, 
                        "Compte créé avec succès ! Vous pouvez maintenant vous connecter.", 
                        "Succès", JOptionPane.INFORMATION_MESSAGE);
                    usernameField.setText("");
                    passwordField.setText("");
                    closeConnections();
                } else {
                    this.setVisible(false);
                    new Dashboard(socket, in, out, username);
                }
            } else {
                String errorMsg = response.contains(":") ? response.split(":")[1] : response;
                JOptionPane.showMessageDialog(this, errorMsg, "Erreur", JOptionPane.ERROR_MESSAGE);
                closeConnections();
            }

        } catch (ConnectException e) {
            JOptionPane.showMessageDialog(this, 
                "Impossible de se connecter au serveur. Veuillez démarrer le serveur d'abord.", 
                "Erreur de connexion", JOptionPane.ERROR_MESSAGE);
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, 
                "Erreur de communication avec le serveur: " + e.getMessage(), 
                "Erreur", JOptionPane.ERROR_MESSAGE);
        } catch (ClassNotFoundException e) {
            JOptionPane.showMessageDialog(this, 
                "Erreur de traitement de la réponse du serveur.", 
                "Erreur", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    private void closeConnections() {
        try {
            if (in != null) in.close();
            if (out != null) out.close();
            if (socket != null) socket.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception e) {
            e.printStackTrace();
        }

        SwingUtilities.invokeLater(() -> {
            new LoginFrame2();
        });
    }
}
