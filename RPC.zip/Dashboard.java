import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.net.*;

public class Dashboard extends JFrame {

    private Socket socket;
    private ObjectInputStream in;
    private ObjectOutputStream out;

    private String currentUser;

    public Dashboard(Socket socket, ObjectInputStream in, ObjectOutputStream out, String username) {
        this.socket = socket;
        this.in = in;
        this.out = out;
        this.currentUser = username;

        setTitle("Tableau de bord - " + currentUser);
        setSize(500, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Ajouter un WindowListener pour fermer les connexions à la fermeture
        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                closeConnections();
                System.exit(0);
            }
        });

        // CardLayout pour permettre de changer de vue
        CardLayout cardLayout = new CardLayout();
        JPanel cardPanel = new JPanel(cardLayout);

        // Panel pour chaque fonctionnalité
        JPanel createPasswordPanel = createPasswordPanel();
        JPanel modifyPasswordPanel = modifyPasswordPanel();
        JPanel showPasswordsPanel = showPasswordsPanel();
        JPanel deletePasswordPanel = deletePasswordPanel();

        // Ajouter chaque panel dans le CardLayout
        cardPanel.add(createPasswordPanel, "CreatePassword");
        cardPanel.add(modifyPasswordPanel, "ModifyPassword");
        cardPanel.add(showPasswordsPanel, "ShowPasswords");
        cardPanel.add(deletePasswordPanel, "DeletePassword");

        // Création des boutons
        JPanel buttonPanel = new JPanel();
        JButton createPasswordButton = new JButton("Créer mot de passe");
        JButton modifyPasswordButton = new JButton("Modifier mot de passe");
        JButton showPasswordsButton = new JButton("Afficher mots de passe");
        JButton deletePasswordButton = new JButton("Supprimer mot de passe");

        // Action des boutons pour changer la vue
        createPasswordButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                cardLayout.show(cardPanel, "CreatePassword");
            }
        });

        modifyPasswordButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                cardLayout.show(cardPanel, "ModifyPassword");
            }
        });

        showPasswordsButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                cardLayout.show(cardPanel, "ShowPasswords");
                // Rafraîchir l'affichage des mots de passe
                refreshPasswordsPanel(cardPanel);
            }
        });

        deletePasswordButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                cardLayout.show(cardPanel, "DeletePassword");
            }
        });

        // Ajouter les boutons au panel
        buttonPanel.setLayout(new GridLayout(4, 1));
        buttonPanel.add(createPasswordButton);
        buttonPanel.add(modifyPasswordButton);
        buttonPanel.add(showPasswordsButton);
        buttonPanel.add(deletePasswordButton);

        // Disposition générale
        setLayout(new BorderLayout());
        add(buttonPanel, BorderLayout.WEST);
        add(cardPanel, BorderLayout.CENTER);

        setVisible(true);
    }

    // Panel pour créer un mot de passe
    private JPanel createPasswordPanel() {
        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));

        panel.add(new JLabel("Créer un mot de passe"));

        // Champ pour le nom du compte
        JTextField accountField = new JTextField(20);
        panel.add(new JLabel("Nom du compte :"));
        panel.add(accountField);

        // Champ pour le mot de passe
        JTextField passwordField = new JTextField(20);
        panel.add(new JLabel("Mot de passe :"));
        panel.add(passwordField);

        // Bouton de sauvegarde
        JButton saveButton = new JButton("Sauvegarder");

        saveButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String account = accountField.getText();
                String password = passwordField.getText();

                if (account.isEmpty() || password.isEmpty()) {
                    JOptionPane.showMessageDialog(Dashboard.this, "Le nom du compte et le mot de passe sont obligatoires.");
                } else {
                    try {
                        // Envoyer la requête de création au serveur
                        out.writeObject("CREATE:" + account + ":" + password);
                        out.flush(); // Vider le buffer après envoi
                        String response = (String) in.readObject();
                        JOptionPane.showMessageDialog(Dashboard.this, response);
                        // Vider les champs après succès
                        accountField.setText("");
                        passwordField.setText("");
                    } catch (IOException | ClassNotFoundException ex) {
                        JOptionPane.showMessageDialog(Dashboard.this, "Erreur de communication avec le serveur: " + ex.getMessage());
                        ex.printStackTrace();
                    }
                }
            }
        });

        panel.add(saveButton);
        return panel;
    }

    // Panel pour modifier un mot de passe
    private JPanel modifyPasswordPanel() {
        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));

        panel.add(new JLabel("Modifier un mot de passe"));

        // Champ pour choisir le nom du compte
        JTextField accountField = new JTextField(20);
        panel.add(new JLabel("Nom du compte (ex: Instagram) :"));
        panel.add(accountField);

        // Champ pour le nouveau mot de passe
        JTextField newPasswordField = new JTextField(20);
        panel.add(new JLabel("Nouveau mot de passe :"));
        panel.add(newPasswordField);

        // Bouton pour modifier
        JButton modifyButton = new JButton("Modifier");

        modifyButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String account = accountField.getText();
                String newPassword = newPasswordField.getText();

                if (account.isEmpty() || newPassword.isEmpty()) {
                    JOptionPane.showMessageDialog(Dashboard.this, "Le nom du compte et le nouveau mot de passe sont obligatoires.");
                } else {
                    try {
                        // Envoyer la requête de modification au serveur
                        out.writeObject("MODIFY:" + account + ":" + newPassword);
                        out.flush(); // Vider le buffer après envoi
                        String response = (String) in.readObject();
                        JOptionPane.showMessageDialog(Dashboard.this, response);
                        // Vider les champs après succès
                        accountField.setText("");
                        newPasswordField.setText("");
                    } catch (IOException | ClassNotFoundException ex) {
                        JOptionPane.showMessageDialog(Dashboard.this, "Erreur de communication avec le serveur: " + ex.getMessage());
                        ex.printStackTrace();
                    }
                }
            }
        });

        panel.add(modifyButton);
        return panel;
    }

    // Panel pour afficher les mots de passe
    private JPanel showPasswordsPanel() {
        JPanel panel = new JPanel();
        panel.setLayout(new BorderLayout());

        panel.add(new JLabel("Afficher les mots de passe"), BorderLayout.NORTH);

        // Créer un panneau qui sera mis à jour dynamiquement
        JTextArea textArea = new JTextArea();
        textArea.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(textArea);
        panel.add(scrollPane, BorderLayout.CENTER);

        // Bouton pour rafraîchir
        JButton refreshButton = new JButton("Rafraîchir");
        refreshButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    out.writeObject("SHOW:");
                    out.flush();
                    String response = (String) in.readObject();
                    textArea.setText(response);
                } catch (IOException | ClassNotFoundException ex) {
                    JOptionPane.showMessageDialog(Dashboard.this, "Erreur de communication avec le serveur: " + ex.getMessage());
                    ex.printStackTrace();
                }
            }
        });
        panel.add(refreshButton, BorderLayout.SOUTH);

        return panel;
    }

    // Méthode pour rafraîchir l'affichage des mots de passe
    private void refreshPasswordsPanel(JPanel cardPanel) {
        // Cette méthode peut être utilisée pour mettre à jour automatiquement l'affichage
    }

    // Panel pour supprimer un mot de passe
    private JPanel deletePasswordPanel() {
        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));

        panel.add(new JLabel("Supprimer un mot de passe"));

        // Champ pour le nom du compte
        JTextField accountField = new JTextField(20);
        panel.add(new JLabel("Nom du compte à supprimer :"));
        panel.add(accountField);

        // Bouton pour supprimer
        JButton deleteButton = new JButton("Supprimer");

        deleteButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String account = accountField.getText();

                if (account.isEmpty()) {
                    JOptionPane.showMessageDialog(Dashboard.this, "Le nom du compte est obligatoire.");
                } else {
                    try {
                        // Envoyer la requête de suppression au serveur
                        out.writeObject("DELETE:" + account);
                        out.flush(); // Vider le buffer après envoi
                        String response = (String) in.readObject();
                        JOptionPane.showMessageDialog(Dashboard.this, response);
                        // Vider le champ après succès
                        accountField.setText("");
                    } catch (IOException | ClassNotFoundException ex) {
                        JOptionPane.showMessageDialog(Dashboard.this, "Erreur de communication avec le serveur: " + ex.getMessage());
                        ex.printStackTrace();
                    }
                }
            }
        });

        panel.add(deleteButton);
        return panel;
    }
    
    // Méthode pour fermer les connexions proprement
    private void closeConnections() {
        try {
            if (in != null) in.close();
            if (out != null) out.close();
            if (socket != null) socket.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
