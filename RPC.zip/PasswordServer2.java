import java.io.*;
import java.net.*;
import java.util.*;
import java.nio.file.*;

public class PasswordServer2 {
    private static final int PORT = 12345;
    private static final String USERS_FILE = "users.txt";
    private static final String PASSWORDS_DIR = "passwords/";
    
    private static Map<String, String> users = new HashMap<>();
    private static Map<String, Map<String, String>> userPasswords = new HashMap<>();

    public static void main(String[] args) {
        initializeServer();
        
        try (ServerSocket serverSocket = new ServerSocket(PORT)) {
            System.out.println("Serveur démarré sur le port " + PORT);
            System.out.println("En attente de connexions clients...");

            while (true) {
                handleClientConnection(serverSocket.accept());
            }
        } catch (IOException e) {
            System.err.println("Erreur du serveur: " + e.getMessage());
        }
    }

    private static void initializeServer() {
        try {
            Files.createDirectories(Paths.get(PASSWORDS_DIR));
            if (!Files.exists(Paths.get(USERS_FILE))) {
                Files.createFile(Paths.get(USERS_FILE));
            }
            loadUsers();
            loadAllPasswords();
        } catch (IOException e) {
            System.err.println("Erreur d'initialisation: " + e.getMessage());
            System.exit(1);
        }
    }

    private static void handleClientConnection(Socket clientSocket) {
        System.out.println("Nouvelle connexion: " + clientSocket.getInetAddress());
        
        try (ObjectOutputStream out = new ObjectOutputStream(clientSocket.getOutputStream());
             ObjectInputStream in = new ObjectInputStream(clientSocket.getInputStream())) {
            
            out.flush();
            String currentUser = null;
            
            while (true) {
                try {
                    String request = (String) in.readObject();
                    System.out.println("Requête reçue: " + request);
                    
                    String[] parts = request.split(":", 3);
                    String response = processRequest(parts, currentUser);
                    
                    if (response.startsWith("SUCCESS") && parts[0].equals("LOGIN")) {
                        currentUser = parts[1];
                    }
                    
                    out.writeObject(response);
                    out.flush();
                    
                } catch (EOFException e) {
                    System.out.println("Client déconnecté");
                    break;
                } catch (ClassNotFoundException | IOException e) {
                    System.err.println("Erreur: " + e.getMessage());
                    break;
                }
            }
        } catch (IOException e) {
            System.err.println("Erreur client: " + e.getMessage());
        } finally {
            try {
                clientSocket.close();
            } catch (IOException e) {
                System.err.println("Erreur fermeture socket: " + e.getMessage());
            }
        }
    }

    private static String processRequest(String[] parts, String currentUser) {
        if (parts.length == 0) return "ERREUR:Requête vide";
        
        switch (parts[0]) {
            case "LOGIN":
                if (parts.length >= 3) return handleLogin(parts[1], parts[2]);
                break;
            case "REGISTER":
                if (parts.length >= 3) return registerUser(parts[1], parts[2]);
                break;
            case "CREATE":
                if (currentUser != null && parts.length >= 3) return createPassword(currentUser, parts[1], parts[2]);
                break;
            case "MODIFY":
                if (currentUser != null && parts.length >= 3) return modifyPassword(currentUser, parts[1], parts[2]);
                break;
            case "SHOW":
                if (currentUser != null) return showPasswords(currentUser);
                break;
            case "DELETE":
                if (currentUser != null && parts.length >= 2) return deletePassword(currentUser, parts[1]);
                break;
            default:
                return "ERREUR:Commande inconnue";
        }
        return "ERREUR:Paramètres insuffisants";
    }

    private static String handleLogin(String username, String password) {
        if (!users.containsKey(username)) return "ERREUR:Nom d'utilisateur incorrect";
        if (!users.get(username).equals(password)) return "ERREUR:Mot de passe incorrect";
        return "SUCCESS:Connexion réussie";
    }

    private static void loadUsers() throws IOException {
        List<String> lines = Files.readAllLines(Paths.get(USERS_FILE));
        for (String line : lines) {
            String[] parts = line.split(":");
            if (parts.length == 2) users.put(parts[0], parts[1]);
        }
        System.out.println(users.size() + " utilisateurs chargés");
    }

    private static void saveUsers() throws IOException {
        List<String> lines = new ArrayList<>();
        users.forEach((k,v) -> lines.add(k + ":" + v));
        Files.write(Paths.get(USERS_FILE), lines);
    }

    private static void loadAllPasswords() {
        users.keySet().forEach(PasswordServer2::loadUserPasswords);
    }

    private static void loadUserPasswords(String username) {
        Path userFile = Paths.get(PASSWORDS_DIR + username + ".txt");
        userPasswords.put(username, new HashMap<>());
        
        if (!Files.exists(userFile)) return;
        
        try {
            Files.readAllLines(userFile).forEach(line -> {
                String[] parts = line.split(":");
                if (parts.length == 2) userPasswords.get(username).put(parts[0], parts[1]);
            });
        } catch (IOException e) {
            System.err.println("Erreur chargement mots de passe pour " + username);
        }
    }

    private static void saveUserPasswords(String username) throws IOException {
        List<String> lines = new ArrayList<>();
        userPasswords.get(username).forEach((k,v) -> lines.add(k + ":" + v));
        Files.write(Paths.get(PASSWORDS_DIR + username + ".txt"), lines);
    }

    private static String registerUser(String username, String password) {
        if (users.containsKey(username)) return "ERREUR:Nom d'utilisateur existe déjà";
        if (username.length() < 3) return "ERREUR:Nom trop court (min 3 caractères)";
        if (password.length() < 4) return "ERREUR:Mot de passe trop court (min 4 caractères)";
        
        try {
            users.put(username, password);
            userPasswords.put(username, new HashMap<>());
            saveUsers();
            saveUserPasswords(username);
            return "SUCCESS:Compte créé avec succès";
        } catch (IOException e) {
            return "ERREUR:Erreur sauvegarde compte";
        }
    }

    private static String createPassword(String username, String account, String password) {
        try {
            userPasswords.get(username).put(account, password);
            saveUserPasswords(username);
            return "SUCCESS:Mot de passe créé pour " + account;
        } catch (IOException e) {
            return "ERREUR:Erreur sauvegarde mot de passe";
        }
    }

    private static String modifyPassword(String username, String account, String newPassword) {
        if (!userPasswords.get(username).containsKey(account)) {
            return "ERREUR:Compte non trouvé";
        }
        try {
            userPasswords.get(username).put(account, newPassword);
            saveUserPasswords(username);
            return "SUCCESS:Mot de passe modifié pour " + account;
        } catch (IOException e) {
            return "ERREUR:Erreur modification mot de passe";
        }
    }

    private static String showPasswords(String username) {
        if (userPasswords.get(username).isEmpty()) return "SUCCESS:Aucun mot de passe enregistré";
        
        StringBuilder sb = new StringBuilder("SUCCESS:Liste des mots de passe:\n");
        userPasswords.get(username).forEach((k,v) -> sb.append(k).append(":").append(v).append("\n"));
        return sb.toString();
    }

    private static String deletePassword(String username, String account) {
        if (!userPasswords.get(username).containsKey(account)) {
            return "ERREUR:Compte non trouvé";
        }
        try {
            userPasswords.get(username).remove(account);
            saveUserPasswords(username);
            return "SUCCESS:Mot de passe supprimé pour " + account;
        } catch (IOException e) {
            return "ERREUR:Erreur suppression mot de passe";
        }
    }
}
